# greenteamnetworks@v2.0.0

GreenTeam Networks is an npm networking/API configuration toolkit.

## Install

```bash
npm install greenteamnetworks
```

## Commands

```bash
greenteamnetworks version
greenteamnetworks help
greenteamnetworks status
greenteamnetworks config

greenteamnetworks apiurl
greenteamnetworks apiurl get
greenteamnetworks apiurl set https://example.com/api
greenteamnetworks apiurl edit https://example.com/api
greenteamnetworks apiurl delete
greenteamnetworks apiurl clear
greenteamnetworks apiurl test
```

The API URL is saved locally in the user's `.greenteamnetworks/config.json`.

## npm project scripts

```bash
npm start
npm run build
npm test
```

## Important npm note

An installed package cannot redefine npm's built-in `npm set` command. Use
`greenteamnetworks apiurl set ...` for the package CLI, or build a separate
project wrapper if you want a custom `npm set`-style command.

## API environment variable

You can also use:

```text
GREENTEAMNETWORKS_API_URL
```

Example PowerShell:

```powershell
$env:GREENTEAMNETWORKS_API_URL="https://example.com/api"
```
