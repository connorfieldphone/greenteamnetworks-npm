const fs = require("fs");
const os = require("os");
const path = require("path");
const https = require("https");

const CONFIG_DIR = path.join(os.homedir(), ".greenteamnetworks");
const CONFIG_FILE = path.join(CONFIG_DIR, "config.json");

function readConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8")); }
  catch { return {}; }
}

function writeConfig(config) {
  fs.mkdirSync(CONFIG_DIR, { recursive: true });
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

function getApiUrl() {
  return readConfig().apiurl || process.env.GREENTEAMNETWORKS_API_URL || "";
}

function setApiUrl(url) {
  const config = readConfig();
  config.apiurl = String(url);
  writeConfig(config);
  return config.apiurl;
}

function deleteApiUrl() {
  const config = readConfig();
  delete config.apiurl;
  writeConfig(config);
}

function request(url, method="GET") {
  return new Promise((resolve,reject)=>{
    https.request(url,{method,headers:{"User-Agent":"greenteamnetworks/2.0.0"}},res=>{
      let data="";
      res.on("data",d=>data+=d);
      res.on("end",()=>resolve({status:res.statusCode,data}));
    }).on("error",reject).end();
  });
}

async function health() {
  const url=getApiUrl();
  if(!url) throw new Error("No API URL configured.");
  return request(url.replace(/\/$/,"")+"/health");
}

module.exports={
  version:"2.0.0",
  getApiUrl,
  setApiUrl,
  deleteApiUrl,
  health
};
