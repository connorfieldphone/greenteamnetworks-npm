# Project Knowledge

Place project-specific documentation here for a local AI integration to index.
