# Local Models

Place an authorised compatible local model/inference runtime here or configure an external local runtime. This package itself does not download a hosted model or require an API token.
