# GreenTeam AI System

Local-first, moderate safety, project-aware assistant.

Allowed: programming, debugging, project work, harmless simulations and defensive/educational security.
Refused: real malware, credential theft, destructive attacks, persistence or evasion.
