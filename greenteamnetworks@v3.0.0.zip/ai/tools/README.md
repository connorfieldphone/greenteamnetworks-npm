# AI Tools

Safe project tools are represented by the CLI: files, project, knowledge, memory, networking, runtime, VM configuration, diagnostics and build orchestration.
