Place .ico/.icns/.png assets here and set the chosen path in package.aijson.
