# Build system

npm AI init
npm AI init --man
npm start AI CodeFox
npm run build AI CodeFox --win32
npm run build AI CodeFox --win64
npm run build AI CodeFox --linux
npm run build AI CodeFox --macos
npm run build AI CodeFox --android
npm run build AI CodeFox --ios
npm run build AI CodeFox --all

Outputs are placed under dist/greenteamnetworks/<AIName>. The package records executable name, icon, version and target metadata. Native installers, executable signing and platform-specific packaging require their respective platform toolchains.
