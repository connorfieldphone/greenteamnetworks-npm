# Custom AI Builder

`npm AI init` automatically creates a custom AI project.

`npm AI init --man` asks for name, version, display name, executable name, icon and description.

Custom AI settings live in `package.aijson`. The project can inherit GreenTeam AI's safety, memory, tools and project-context architecture while using a local model provider.
