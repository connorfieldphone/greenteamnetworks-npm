# Update system

GreenTeam release versions use semantic versioning:
patch 1.0.0 -> 1.0.1
minor 1.0.0 -> 1.1.0
major 1.0.0 -> 2.0.0

Each release ZIP contains `updatenotes@v<version>.txt`.
A production updater should verify release integrity before replacing an installed application. This package intentionally does not silently replace files from an untrusted URL.
