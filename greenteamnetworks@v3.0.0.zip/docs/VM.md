# Virtual machine / sandbox feature

The v3 architecture provides a VM configuration layer and isolated-network settings. It does not pretend to be a hypervisor.

`greenteamnetworks vm create Demo`
`greenteamnetworks vm list`
`greenteamnetworks vm remove Demo`

For a real VM, connect this configuration layer to a legitimate hypervisor/runtime such as Hyper-V, VirtualBox, VMware or another supported local system.
