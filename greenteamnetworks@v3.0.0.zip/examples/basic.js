const G=require("../lib");console.log(G.ai.answer("hello",{ai:{memory:[]},version:G.version}));
