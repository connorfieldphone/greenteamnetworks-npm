# Local Provider Architecture

GreenTeam AI has a provider interface so a local model can be connected without OpenAI/Anthropic/Gemini API keys.
