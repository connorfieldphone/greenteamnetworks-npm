# GreenTeam application template

Use npm AI init to create a custom AI project.
