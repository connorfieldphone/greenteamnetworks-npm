# GreenTeam AI v4
Local-first AI project configuration.
