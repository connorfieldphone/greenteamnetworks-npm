Place your Windows .ico file here and set its path in package.aijson.
