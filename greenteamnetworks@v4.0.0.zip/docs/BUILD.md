# v4 real Electron build

Run:
npm install
npm run AI -- init
npm start
npm run build:win64
npm run build:portable

The build command now invokes electron-builder and produces real Electron Windows output instead of only metadata.
