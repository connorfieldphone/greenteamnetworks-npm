# Correct npm commands

`npm AI init` is not an npm command.

Use:
`npm run AI -- init`
`npm run AI -- init --man`

Or after `npm link`:
`greenteamnetwork ai init`

Build:
`npm run build:win64`
`npm run build:portable`
