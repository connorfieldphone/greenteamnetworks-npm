const {app,BrowserWindow}=require("electron");
const path=require("node:path"),fs=require("node:fs");
function createWindow(){
 const cfg=JSON.parse(fs.readFileSync(path.join(__dirname,"..","package.aijson"),"utf8"));
 const iconPath=path.join(__dirname,"..",cfg.icon||"");
 const win=new BrowserWindow({width:1100,height:700,title:cfg.displayName||cfg.name||"GreenTeam AI",
 icon:fs.existsSync(iconPath)?iconPath:undefined,webPreferences:{contextIsolation:true,nodeIntegration:false}});
 win.loadFile(path.join(__dirname,"index.html"));
}
app.whenReady().then(()=>{app.setAppUserModelId("com.greenteamnetworks.ai");createWindow()});
app.on("window-all-closed",()=>{if(process.platform!=="darwin")app.quit()});
