# GreenTeam AI v4.0.0

Local-first AI project.

No API key or online AI service is required by the
base project configuration.

Models can be placed under:

ai/models/
