Put your application .ico file here.

Then set:

"icon": "./assets/icon/app.ico"

inside package.aijson.
