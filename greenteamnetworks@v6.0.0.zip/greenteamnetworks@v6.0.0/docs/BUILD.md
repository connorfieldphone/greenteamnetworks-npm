# Building

Install dependencies:

npm install

Initialize:

npm run AI -- init

Manual initialization:

npm run AI -- init --man

Start:

npm start

Windows x64:

npm run build:win64

Portable:

npm run build:portable

Output:

dist/greenteamnetworks/
