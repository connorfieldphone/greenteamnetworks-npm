# Commands

greenteamnetwork help
greenteamnetwork version
greenteamnetwork status
greenteamnetwork doctor

greenteamnetwork folder

greenteamnetwork bump patch
greenteamnetwork bump minor
greenteamnetwork bump major

Aliases:

gn help
gn version
gn status

gtn help
gtnet help

GRNPMS:

grnpms help
grnpms update <zip>
