# GRNPMS

GreenTeam Networks Package Management System.

## Update behaviour

grnpms update update.zip

Rules:

1. Files existing in the ZIP replace matching files.
2. New files in the ZIP are added.
3. Existing files missing from the ZIP are NOT deleted.
4. The updater never wipes the whole project.

## Custom verbs

grnpms verb add deploy "npm run build:win64"

grnpms verb edit deploy "npm run build:portable"

grnpms verb list

## Custom commands

grnpms command add hello "echo Hello"

grnpms command list

## Environment

grnpms env set MODE development

grnpms env get MODE

grnpms env list
