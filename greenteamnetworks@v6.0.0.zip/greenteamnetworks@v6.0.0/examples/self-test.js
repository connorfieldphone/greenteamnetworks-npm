const fs =
    require("node:fs");

const pkg =
    require("../package.json");

const required =
    [
        "electron",
        "electron-builder"
    ];

for (
    const item of required
) {

    if (
        !pkg.devDependencies[item]
    ) {

        throw new Error(
            item + " missing"
        );
    }
}

for (
    const item of
    [
        "package.aijson",
        "bin/grnpms.js",
        "bin/greenteamnetwork.js"
    ]
) {

    if (
        !fs.existsSync(item)
    ) {

        throw new Error(
            item + " missing"
        );
    }
}

console.log(
    "GreenTeam Networks v4.0.0 configuration OK"
);
